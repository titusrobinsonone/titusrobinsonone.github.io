import unittest
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import revenue_forensics as rev

class RevenueTests(unittest.TestCase):
    @staticmethod
    def events():
        return [dict(event_id=f'E{i}',customer_id='A',effective_month=f'2026-{i+1:02}',mrr_cents=cents,segment='SMB',sequence=i)
                for i,cents in enumerate([10000,15000,8000,0,9000])]

    def test_expansion_contraction_churn_reactivation_are_distinct(self):
        data,db,_=rev.model(self.events(),end_month='2026-05');db.close();b=data['bridges']
        self.assertEqual(b[0]['new'],10000);self.assertEqual(b[1]['expansion'],5000)
        self.assertEqual(b[2]['contraction'],7000);self.assertEqual(b[3]['churn'],8000)
        self.assertEqual(b[4]['reactivation'],9000);self.assertEqual(b[4]['new'],0)
        self.assertTrue(all(r['residual']==0 for r in b))

    def test_state_is_carried_through_a_month_without_events(self):
        data,db,_=rev.model(self.events()[:1],end_month='2026-03');db.close()
        self.assertEqual([r['closing'] for r in data['bridges']],[10000]*3)
        self.assertEqual(data['bridges'][1]['new'],0)

    def test_duplicate_events_do_not_inflate_revenue(self):
        rows=self.events(); data,db,bad=rev.model(rows+[rows[0]],end_month='2026-05');db.close()
        self.assertEqual(data['bridges'][0]['closing'],10000)
        self.assertEqual(bad[0]['reason'],'duplicate_event_id')

    def test_invalid_money_and_changing_segments_are_quarantined(self):
        rows=self.events(); rows+=[dict(rows[0],event_id='bad',mrr_cents=-1),dict(rows[1],event_id='wrong',segment='Mid-market')]
        good,bad=rev.validate(rows)
        self.assertEqual(len(good),5)
        self.assertEqual([r['reason'] for r in bad],['invalid_mrr','segment_changed'])

    def test_latest_sequence_in_month_determines_closing_mrr(self):
        rows=self.events()[:1]+[dict(self.events()[0],event_id='later',sequence=99,mrr_cents=20000)]
        data,db,_=rev.model(rows,end_month='2026-01');db.close()
        self.assertEqual(data['bridges'][0]['closing'],20000)

if __name__=="__main__": unittest.main()
