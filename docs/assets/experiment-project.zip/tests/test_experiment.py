import unittest
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import math
import experiment_studio as exp

class ExperimentTests(unittest.TestCase):
    def test_balanced_and_broken_allocations(self):
        self.assertEqual(exp.srm(10000,10000)['pValue'],1)
        self.assertFalse(exp.srm(12000,9600)['passed'])

    def test_difference_interval_and_direction(self):
        x=exp.difference(200,1000,240,1000)
        se=math.sqrt(.2*.8/1000+.24*.76/1000)
        self.assertAlmostEqual(x['delta'],.04)
        self.assertAlmostEqual(x['lower'],.04-exp.Z95*se)
        reversed_result=exp.difference(240,1000,200,1000)
        self.assertAlmostEqual(reversed_result['delta'],-x['delta'])

    def test_allocation_failure_overrides_large_positive_effect(self):
        result=dict(allocation=dict(passed=False),conversion=exp.difference(100,1000,300,1000),errors=exp.difference(20,1000,20,1000))
        self.assertEqual(exp.decide(result),'Investigate allocation')

    def test_guardrail_regression_overrides_positive_conversion(self):
        result=dict(allocation=dict(passed=True),conversion=exp.difference(1000,10000,1500,10000),errors=exp.difference(100,10000,500,10000))
        self.assertEqual(exp.decide(result),'Stop: guardrail regression')

    def test_invalid_counts_and_duplicate_users_fail(self):
        with self.assertRaises(ValueError): exp.difference(0,0,2,10)
        row=dict(user_id='a',variant='control',converted=0,error=0)
        with self.assertRaises(ValueError): exp.analyze([row,row])

if __name__=="__main__": unittest.main()
