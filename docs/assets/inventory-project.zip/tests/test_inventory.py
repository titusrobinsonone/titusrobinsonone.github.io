import unittest
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import copy
import inventory_lab as inv

class InventoryTests(unittest.TestCase):
    def setUp(self): self.rows=inv.generate_demo(days=112,skus=1)

    def test_future_changes_do_not_change_prior_predictions(self):
        altered=copy.deepcopy(self.rows)
        for r in altered[100:]: r['demand']=10000
        a=inv.simulate_sku(self.rows,'seasonal',7,1.645)['trace']
        b=inv.simulate_sku(altered,'seasonal',7,1.645)['trace']
        self.assertEqual(a[:16],b[:16])

    def test_stock_flow_reconciles_and_cannot_sell_missing_stock(self):
        result=inv.simulate_sku(self.rows,'rolling',7,0)
        for r in result['trace']:
            self.assertEqual(r['opening']+r['arrivals']-r['sold'],r['closing'])
            self.assertEqual(r['sold']+r['lost'],r['demand'])
            self.assertGreaterEqual(r['closing'],0)
        self.assertEqual(result['demand'],result['fulfilled']+result['lost'])

    def test_orders_arrive_after_exact_lead_time(self):
        result=inv.simulate_sku(self.rows,'rolling',3,1)['trace']
        for i,row in enumerate(result): self.assertEqual(row['arrivals'],result[i-3]['ordered'] if i>=3 else 0)

    def test_duplicate_or_missing_days_rejected(self):
        with self.assertRaises(ValueError): inv.validate(self.rows+[self.rows[0]])
        with self.assertRaises(ValueError): inv.validate(self.rows[:95]+self.rows[96:])

if __name__=="__main__": unittest.main()
